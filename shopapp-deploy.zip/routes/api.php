<?php

declare(strict_types=1);

use App\Http\Controllers\Api\V1\Auth\AuthController;
use App\Http\Controllers\Api\V1\Auth\PasswordResetController;
use App\Http\Controllers\Api\V1\Cart\CartController;
use App\Http\Controllers\Api\V1\Catalog\CategoryController;
use App\Http\Controllers\Api\V1\Catalog\ProductController;
use App\Http\Controllers\Api\V1\Checkout\CheckoutController;
use App\Http\Controllers\Api\V1\Favorites\FavoriteController;
use App\Http\Controllers\Api\V1\Notifications\DeviceController;
use App\Http\Controllers\Api\V1\Notifications\NotificationController;
use App\Http\Controllers\Api\V1\Profile\ProfileController;
use App\Http\Controllers\Api\V1\Settings\AppSettingsController;
use Illuminate\Support\Facades\Route;

Route::prefix('v1')->group(function (): void {
    /*
    |--------------------------------------------------------------------------
    | Auth (public)
    |--------------------------------------------------------------------------
    */
    Route::prefix('auth')->group(function (): void {
        Route::post('register', [AuthController::class, 'register'])
            ->middleware('throttle:auth');

        Route::post('login', [AuthController::class, 'login'])
            ->middleware('throttle:auth');

        Route::post('refresh', [AuthController::class, 'refresh'])
            ->middleware('throttle:auth');

        Route::prefix('password')->middleware('throttle:auth')->group(function (): void {
            Route::post('forgot', [PasswordResetController::class, 'forgot']);
            Route::post('verify', [PasswordResetController::class, 'verify']);
            Route::post('resend', [PasswordResetController::class, 'resend']);
            Route::post('reset', [PasswordResetController::class, 'reset']);
        });

        // Bearer-protected.
        Route::post('logout', [AuthController::class, 'logout'])
            ->middleware('auth:sanctum');
    });

    /*
    |--------------------------------------------------------------------------
    | Storefront config & catalog (public)
    |--------------------------------------------------------------------------
    */
    Route::get('settings/app', [AppSettingsController::class, 'show']);
    Route::get('categories', [CategoryController::class, 'index']);
    Route::get('products', [ProductController::class, 'index']);
    Route::get('products/{id}', [ProductController::class, 'show']);

    /*
    |--------------------------------------------------------------------------
    | Authenticated (bearer)
    |--------------------------------------------------------------------------
    */
    Route::middleware('auth:sanctum')->group(function (): void {
        // Cart
        Route::get('cart', [CartController::class, 'show']);
        Route::post('cart', [CartController::class, 'store']);
        Route::patch('cart/{lineId}', [CartController::class, 'update'])
            ->where('lineId', '.*');
        Route::delete('cart/{lineId}', [CartController::class, 'destroy'])
            ->where('lineId', '.*');
        Route::delete('cart', [CartController::class, 'clear']);
        Route::post('cart/promo', [CartController::class, 'promo'])
            ->middleware('throttle:promo');

        // Favorites
        Route::get('favorites', [FavoriteController::class, 'index']);
        Route::post('favorites', [FavoriteController::class, 'toggle']);
        Route::delete('favorites', [FavoriteController::class, 'clear']);

        // Checkout
        Route::post('checkout', [CheckoutController::class, 'store']);

        // Notifications
        Route::get('notifications', [NotificationController::class, 'index']);
        Route::post('notifications/read', [NotificationController::class, 'read']);
        Route::get('notifications/count', [NotificationController::class, 'count']);
        Route::post('notifications/devices', [DeviceController::class, 'store']);
        Route::delete('notifications/devices', [DeviceController::class, 'destroy']);

        // Profile
        Route::get('me', [ProfileController::class, 'show']);
        Route::patch('me', [ProfileController::class, 'update']);
        Route::get('me/orders', [ProfileController::class, 'orders']);
    });
});
