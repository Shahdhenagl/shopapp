<?php

declare(strict_types=1);

use App\Domain\Auth\Models\User;
use Illuminate\Support\Facades\Hash;

it('registers a user and returns a flat token and user', function (): void {
    $response = $this->postJson('/api/v1/auth/register', [
        'name' => 'John Doe',
        'email' => 'john@example.com',
        'phone' => '+201234567890',
        'password' => 'password123',
        'password_confirmation' => 'password123',
    ], ['Accept' => 'application/json']);

    $response->assertStatus(201);

    $response->assertJsonStructure([
        'token',
        'user' => ['id', 'name', 'email', 'phone', 'avatar_url'],
    ]);

    // Assert FLAT response — no 'data' wrapper.
    expect($response->json('token'))->not->toBeNull();
    expect($response->json())->not->toHaveKey('data');
    $response->assertJsonPath('user.email', 'john@example.com');
});

it('logs in with correct credentials returning a flat token and user', function (): void {
    User::factory()->create([
        'email' => 'a@b.com',
        'password' => Hash::make('password123'),
    ]);

    $response = $this->postJson('/api/v1/auth/login', [
        'email' => 'a@b.com',
        'password' => 'password123',
    ], ['Accept' => 'application/json']);

    $response->assertStatus(200);
    $response->assertJsonStructure([
        'token',
        'user' => ['id', 'name', 'email', 'phone', 'avatar_url'],
    ]);
    expect($response->json('token'))->not->toBeNull();
    expect($response->json())->not->toHaveKey('data');
});

it('rejects login with a wrong password', function (): void {
    User::factory()->create([
        'email' => 'a@b.com',
        'password' => Hash::make('password123'),
    ]);

    $response = $this->postJson('/api/v1/auth/login', [
        'email' => 'a@b.com',
        'password' => 'wrong-password',
    ], ['Accept' => 'application/json']);

    $response->assertStatus(401);
});

it('logs out an authenticated user', function (): void {
    $user = User::factory()->create();
    $token = $user->createToken('test')->plainTextToken;

    $response = $this->postJson('/api/v1/auth/logout', [], [
        'Accept' => 'application/json',
        'Authorization' => 'Bearer ' . $token,
    ]);

    $response->assertNoContent();
});
