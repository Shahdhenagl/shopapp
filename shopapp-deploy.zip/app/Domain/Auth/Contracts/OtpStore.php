<?php

declare(strict_types=1);

namespace App\Domain\Auth\Contracts;

/**
 * Narrow contract (ISP) for issuing/validating one-time reset codes.
 *
 * Implementations hash the code at rest, enforce a TTL, and cap attempts.
 */
interface OtpStore
{
    /**
     * Generate, persist (hashed) and return the plaintext code for the email.
     */
    public function issue(string $email): string;

    /**
     * Verify a plaintext code against the latest unexpired record for the
     * email, marking it verified on success. Returns true on success.
     */
    public function verify(string $email, string $code): bool;

    /**
     * Whether a verified, unexpired, unconsumed code exists for the email
     * (required by the password reset step which only sends {email,password}).
     */
    public function hasVerified(string $email): bool;

    /**
     * Consume (invalidate) the active verified code for the email.
     */
    public function consume(string $email): void;
}
