<?php

declare(strict_types=1);

namespace App\Domain\Auth\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

final class SendOtpMail extends Mailable implements ShouldQueue
{
    use Queueable;
    use SerializesModels;

    public function __construct(
        public readonly string $code,
        public readonly int $ttlMinutes,
    ) {
    }

    public function envelope(): Envelope
    {
        return new Envelope(
            subject: __('api.reset_code_sent'),
        );
    }

    public function content(): Content
    {
        return new Content(
            htmlString: sprintf(
                '<p>Your MODIST password reset code is <strong>%s</strong>.</p>'
                .'<p>It expires in %d minutes. If you did not request this, ignore this email.</p>',
                e($this->code),
                $this->ttlMinutes,
            ),
        );
    }
}
