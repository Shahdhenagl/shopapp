<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Auth;

use App\Domain\Auth\Actions\LoginAction;
use App\Domain\Auth\Actions\LogoutAction;
use App\Domain\Auth\Actions\RefreshAccessTokenAction;
use App\Domain\Auth\Actions\RegisterAction;
use App\Domain\Auth\Models\User;
use App\Http\Controllers\Controller;
use App\Http\Requests\Api\V1\Auth\LoginRequest;
use App\Http\Requests\Api\V1\Auth\RefreshTokenRequest;
use App\Http\Requests\Api\V1\Auth\RegisterRequest;
use App\Http\Resources\UserResource;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class AuthController extends Controller
{
    public function __construct(
        private readonly RegisterAction $registerAction,
        private readonly LoginAction $loginAction,
        private readonly LogoutAction $logoutAction,
        private readonly RefreshAccessTokenAction $refreshAccessTokenAction,
    ) {
    }

    public function register(RegisterRequest $request): JsonResponse
    {
        $result = $this->registerAction->execute(
            $request->validated('name'),
            $request->validated('email'),
            $request->validated('phone'),
            $request->validated('password'),
        );

        return response()->json([
            'token' => $result->token,
            'refresh_token' => $result->refreshToken,
            'user' => UserResource::make($result->user)->resolve($request),
        ], 201);
    }

    public function login(LoginRequest $request): JsonResponse
    {
        $result = $this->loginAction->execute(
            $request->validated('email'),
            $request->validated('password'),
        );

        return response()->json([
            'token' => $result->token,
            'refresh_token' => $result->refreshToken,
            'user' => UserResource::make($result->user)->resolve($request),
        ], 200);
    }

    public function refresh(RefreshTokenRequest $request): JsonResponse
    {
        $result = $this->refreshAccessTokenAction->execute(
            $request->validated('refresh_token'),
        );

        return response()->json([
            'token' => $result->token,
            'refresh_token' => $result->refreshToken,
            'user' => UserResource::make($result->user)->resolve($request),
        ], 200);
    }

    public function logout(Request $request): Response
    {
        /** @var User $user */
        $user = $request->user();

        $this->logoutAction->execute($user);

        return response()->noContent();
    }
}
