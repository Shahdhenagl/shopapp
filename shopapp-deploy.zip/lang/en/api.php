<?php

declare(strict_types=1);

return [

    /*
    |--------------------------------------------------------------------------
    | API Message Language Lines
    |--------------------------------------------------------------------------
    |
    | Custom message keys returned by the MODIST API across the various
    | controllers and actions. Resolved through the Accept-Language header.
    |
    */

    // Generic
    'unauthenticated' => 'Unauthenticated.',
    'not_found' => 'Resource not found.',
    'server_error' => 'Something went wrong. Please try again.',

    // Authentication
    'invalid_credentials' => 'The provided credentials are incorrect.',
    'invalid_refresh_token' => 'The refresh token is invalid or has expired.',
    'logged_out' => 'Logged out successfully.',

    // Password reset
    'reset_code_sent' => 'If the account exists, a reset code has been sent.',
    'reset_code_invalid' => 'The reset code is invalid or has expired.',
    'reset_code_verified' => 'Reset code verified.',
    'reset_code_resent' => 'A new reset code has been sent.',
    'password_reset' => 'Your password has been reset.',
    'no_verified_code' => 'No verified reset code found for this email.',

    // Catalog
    'product_not_found' => 'Product not found.',

    // Cart
    'cart_empty' => 'Your cart is empty.',
    'cart_line_not_found' => 'Cart line not found.',
    'promo_invalid' => 'This promo code is invalid or has expired.',

    // Checkout & payments
    'payment_declined' => 'Your payment was declined.',
    'unsupported_payment_method' => 'This payment method is not supported.',

];
