<?php

declare(strict_types=1);

return [
    // Time-to-live for a reset code, in minutes.
    'ttl_minutes' => (int) env('OTP_TTL_MINUTES', 10),

    // Number of digits in the generated code (4–6).
    'length' => (int) env('OTP_LENGTH', 6),

    // Maximum verify attempts before a code is invalidated.
    'max_attempts' => (int) env('OTP_MAX_ATTEMPTS', 5),
];
